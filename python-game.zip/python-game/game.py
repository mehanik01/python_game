import arcade
import random

# Настройки экрана
screen_width = 500
screen_height = 750
screen_title = "Летающий Самолётик"

# Путь к папке со спрайтами
SPRITES_PATH = "sprites/"

# Цвета
WHITE = arcade.color.WHITE
BLACK = arcade.color.BLACK

# Загрузка и изменение размеров спрайтов
def load_and_scale_image(image_name, scale):
    return SPRITES_PATH + image_name, scale

class FlyingGame(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        self.score = 0
        self.lives = 3
        self.player = None
        self.bullets = None
        self.obstacles = None
        self.background = None
        self.background_2 = None
        self.obstacle_speed = -2.0
        self.obstacle_count = 5
        self.max_bullets = 10
        self.bullets_fired = 0
        self.reload_time = 3.0  # Время перезарядки в секундах
        self.reloading = False
        self.reload_timer = 0.0

    def setup(self):
        self.score = 0
        self.lives = 3
        self.bullets_fired = 0
        self.reloading = False
        self.reload_timer = 0.0

        # Загрузка фоновых изображений
        self.background = arcade.Sprite(SPRITES_PATH + 'background.png', scale=2)
        self.background.center_x = screen_width // 2
        self.background.center_y = screen_height // 2

        self.background_2 = arcade.Sprite(SPRITES_PATH + 'background.png', scale=2)
        self.background_2.center_x = screen_width // 2
        self.background_2.center_y = screen_height + (screen_height // 2)

        self.player = arcade.Sprite(*load_and_scale_image('plane.png', 0.25))
        self.player.center_x = screen_width // 2
        self.player.center_y = 100
        self.player.change_x = 0
        self.player.change_y = 0

        self.bullets = arcade.SpriteList()
        self.obstacles = arcade.SpriteList()

        for _ in range(self.obstacle_count):
            obstacle = arcade.Sprite(*load_and_scale_image('bomb.png', 0.1))
            obstacle.center_x = random.randint(0, screen_width)
            obstacle.center_y = random.randint(screen_height, screen_height + 200)
            obstacle.change_y = random.uniform(self.obstacle_speed, self.obstacle_speed - 3.0)
            self.obstacles.append(obstacle)

    def on_draw(self):
        arcade.start_render()
        # Отрисовка фоновых изображений
        self.background.draw()
        self.background_2.draw()

        # Отрисовка счетчика очков и жизней наверху экрана
        arcade.draw_text(f"Score: {self.score}", 10, screen_height - 40, BLACK, 24)
        arcade.draw_text(f"Lives: {self.lives}", screen_width - 110, screen_height - 40, BLACK, 24)
        
        self.player.draw()
        self.bullets.draw()
        self.obstacles.draw()

        if self.reloading:
            arcade.draw_text("Reloading...", screen_width // 2 - 60, screen_height // 2, BLACK, 24)

    def on_update(self, delta_time):
        self.player.update()
        self.bullets.update()
        self.obstacles.update()

        if self.reloading:
            self.reload_timer += delta_time
            if self.reload_timer >= self.reload_time:
                self.reloading = False
                self.reload_timer = 0.0
                self.bullets_fired = 0

        # Обновление фона для создания эффекта прокрутки
        self.background.center_y -= 1
        self.background_2.center_y -= 1

        # Перемещение фонов, если они выходят за экран
        if self.background.top < 0:
            self.background.center_y = screen_height + (screen_height // 2)
        if self.background_2.top < 0:
            self.background_2.center_y = screen_height + (screen_height // 2)

        # Удаление выстрелов, которые ушли за пределы экрана
        for bullet in self.bullets:
            if bullet.top > screen_height:
                bullet.kill()

        # Удаление бомб, которые ушли за пределы экрана
        for obstacle in self.obstacles:
            if obstacle.bottom < 0:
                obstacle.kill()

        # Проверка столкновений выстрелов с бомбами
        for bullet in self.bullets:
            hit_list = arcade.check_for_collision_with_list(bullet, self.obstacles)
            for obstacle in hit_list:
                obstacle.kill()
                bullet.kill()
                self.score += 1

                # Увеличение скорости и количества бомб после достижения кратных 10 очков
                if self.score % 10 == 0:
                    self.obstacle_speed -= 0.5
                    self.obstacle_count += 1

        # Проверка столкновений самолета с бомбами
        for obstacle in self.obstacles:
            if arcade.check_for_collision(self.player, obstacle):
                obstacle.kill()
                self.lives -= 1
                if self.lives == 0:
                    arcade.close_window()

        # Добавление новых бомб, если их меньше определённого количества
        while len(self.obstacles) < self.obstacle_count:
            obstacle = arcade.Sprite(*load_and_scale_image('bomb.png', 0.1))
            obstacle.center_x = random.randint(0, screen_width)
            obstacle.center_y = random.randint(screen_height, screen_height + 200)
            obstacle.change_y = random.uniform(self.obstacle_speed, self.obstacle_speed - 3.0)
            self.obstacles.append(obstacle)

        # Ограничения перемещения игрока
        if self.player.left < 0:
            self.player.left = 0
        elif self.player.right > screen_width:
            self.player.right = screen_width

        if self.player.bottom < 0:
            self.player.bottom = 0
        elif self.player.top > screen_height:
            self.player.top = screen_height

    def on_key_press(self, key, modifiers):
        if key == arcade.key.LEFT or key == arcade.key.A:
            self.player.change_x = -5
        elif key == arcade.key.RIGHT or key == arcade.key.D:
            self.player.change_x = 5
        elif key == arcade.key.UP or key == arcade.key.W:
            self.player.change_y = 5
        elif key == arcade.key.DOWN or key == arcade.key.S:
            self.player.change_y = -5
        elif key == arcade.key.SPACE and not self.reloading:
            if self.bullets_fired < self.max_bullets:
                bullet = arcade.Sprite(*load_and_scale_image('bullet.jpg', 0.05))
                bullet.center_x = self.player.center_x
                bullet.center_y = self.player.center_y + 20
                bullet.change_y = 5
                self.bullets.append(bullet)
                self.bullets_fired += 1
            if self.bullets_fired >= self.max_bullets:
                self.reloading = True

    def on_key_release(self, key, modifiers):
        if key in (arcade.key.LEFT, arcade.key.RIGHT, arcade.key.A, arcade.key.D):
            self.player.change_x = 0
        elif key in (arcade.key.UP, arcade.key.DOWN, arcade.key.W, arcade.key.S):
            self.player.change_y = 0

if __name__ == "__main__":
    game = FlyingGame(screen_width, screen_height, screen_title)
    game.setup()
    arcade.run()